 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "stdio.h"

//
//int old_main(void)
//{
//    adc_result_t analog_in=0;
//
//    SYSTEM_Initialize();
//    
//    PWM1_16BIT_WritePeriodRegister((uint16_t)309);
//    PWM1_16BIT_SetSlice1Output1DutyCycleRegister((uint16_t)155);            
//    PWM1_16BIT_SetSlice1Output2DutyCycleRegister((uint16_t)155);    
//    PWM1_16BIT_LoadBufferRegisters();
//    
//    while(1)
//    {
//        
//        ADC_ChannelSelect(ADC_CHANNEL_ANA0);
//        ADC_ConversionStart();
//        while (!ADC_IsConversionDone());
//        analog_in=ADC_ConversionResultGet();
//
//        for (uint16_t ii=0;ii<309;ii++){
//            PWM1_16BIT_SetSlice1Output1DutyCycleRegister(ii);            
//            PWM1_16BIT_LoadBufferRegisters();
//            __delay_ms(5);
//        }
//        for (uint16_t ii=0;ii<309;ii++){
//            PWM1_16BIT_SetSlice1Output1DutyCycleRegister(309-ii);            
//            PWM1_16BIT_LoadBufferRegisters();
//            __delay_ms(5);
//        }
//        
//        
//        printf("Value %d\r\n",analog_in);
//       
//        __delay_ms(1000);
//    }    
//}

int main(void)
{
    //create a variable to store the analog value read
    adc_result_t analog_in=0;
    // variable timer stores the timer counter value
    uint16_t timer_cur=0;
    // variable timer_last storest the last counter value from the previous step through the while loop
    uint16_t timer_last=0;
    // timer_last_print stores the last timer value that a printf() occurred
    uint16_t timer_last_print=0;
    // timer_dt stores the difference between timer_last and timer
    uint16_t timer_dt=0;
    // led_state is 0 if counting up and 1 if counting down
    int led_state = 0;
    // led counter value
    int led_ii = 0;
    // amount to multiply the current counter value by to scale to the hardware-enabled PWM.
    // equal to (PWM1PRH<<8|PWM1PRL)/60
    const int PWM_DUTY_SCALING = 9;
    // PWM breathe period of 60 is equivalent to 2s rising, 2s falling
    const int PWM_BREATHE_PERIOD = 60;
    // printf period of 30 is equivalent to 1 s
    const int PRINTF_PERIOD = 30;
    // variable that stores the computed duty cycle
    uint16_t duty=0;
    int conversion_started=0;
    //initialize all subsystems
    SYSTEM_Initialize();
    
    //start the timer counting
    TMR0_Start();
    
    PWM1_16BIT_WritePeriodRegister((uint16_t)((PWM_DUTY_SCALING*PWM_BREATHE_PERIOD)-1));
    PWM1_16BIT_SetSlice1Output1DutyCycleRegister((uint16_t)0);            
    PWM1_16BIT_LoadBufferRegisters();
    
    while(1)
    {
        //get the current time and calculate the difference since last time.
        timer_cur = TMR0_CounterGet();
        timer_dt = timer_cur-timer_last;
        
        //read the analog value on channel 0
        ADC_ChannelSelect(ADC_CHANNEL_ANA0);
        //check to see if a conversion has begun. 
        //if not
        if (conversion_started==0){
            //start the conversion
            ADC_ConversionStart();
            //set "conversion_started"
            conversion_started=1;
        }
        //check to see if a conversion has begun. 
        //if yes
        if (conversion_started!=0){
            //if the conversion has finished
            if (ADC_IsConversionDone()){
                //read the value and set analog_in.
                analog_in=ADC_ConversionResultGet();                
                //clear the conversion_started bit
                conversion_started=0;
            }
        }

        // if led state is "rising" or 0
        if (led_state==0){
            //increase the counter by the amount of time that has elapsed in the timer
            led_ii+=timer_dt;
        }
        //otherwise, the led state is "falling" or 1
        else {
            //decrease the counter by the amount of time that has elapsed in the timer
            led_ii-=timer_dt;
        }
        //set the duty according to the current counter
        duty = ((uint16_t)led_ii)*PWM_DUTY_SCALING;
        PWM1_16BIT_SetSlice1Output1DutyCycleRegister(duty);            
        PWM1_16BIT_LoadBufferRegisters();

        //check limits.  If rising and you hit the upper limit of 60
        if ((led_state==0) && (led_ii>=PWM_BREATHE_PERIOD)){
            //change to falling
            led_state=1;
        }
            
        //otherwise, if falling and you hit the lower limit of 0
        else if ((led_state==1) && (led_ii<=0)){
            //change to rising
            led_state=0;
        }
        
        //if the last time you printed was more than 30 counts ago (1 sec)
        if ((timer_cur-timer_last_print)>PRINTF_PERIOD){
            printf("Value %d %u %u %d %d %u\r\n",analog_in,timer_cur,timer_dt,led_state,led_ii,duty);
            timer_last_print = timer_cur;
        }
        
        //if you have a pushbutton, exit the program
        if (IO_RB4_GetValue()==0) {
            printf("return \n");
            return 0;
        }
       
        //store the current timer value as the "last" value
        timer_last = timer_cur;
        
    }    
}